HW3 
I couldn't figure out how to switch between the ResultsLose and ResultsWin,
while comparing the levels and the character's power. 

References:
NoName's group members